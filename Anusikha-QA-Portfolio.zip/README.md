# Anusikha N — QA Portfolio

A responsive, recruiter-friendly Quality Analyst / Manual Testing portfolio.

## Files
- `index.html` — portfolio content
- `style.css` — responsive design
- `script.js` — mobile navigation and scroll animations
- `resume.pdf` — add your latest resume PDF here before publishing

## Publish with GitHub Pages

1. Create a GitHub repository, for example `anusikha-qa-portfolio`.
2. Upload `index.html`, `style.css`, `script.js`, and your resume as `resume.pdf`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/root`.
6. Save and wait for GitHub Pages to publish the site.

Your portfolio URL will normally look like:
`https://anusikha-1.github.io/anusikha-qa-portfolio/`

## Before publishing
- Confirm your LinkedIn and GitHub links.
- Add the latest resume as `resume.pdf`.
- Add screenshots or links to your actual test cases/defect reports if you want to showcase them.
- Only keep tools/projects you can confidently explain in an interview.
